from django import template

register = template.Library()


@register.filter(name='currency')
def currency(number):
    return "₹ " + str(number)


@register.filter(name='cart_sum')
def cart_sum(values):
    sum = 0
    for value in values:
        sum += int(value)
    return sum

@register.filter(name='multiple')
def multiple(number, number1):
    return number * number1





