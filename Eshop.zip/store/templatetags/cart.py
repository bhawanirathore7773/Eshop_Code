from django import template

register = template.Library()


@register.filter(name='is_in_cart')
def is_in_cart(product, cart):
    keys = cart.keys()
    for id in keys:
        if int(id) == product.id:
            return True
    return False;


@register.filter(name='cart_quantity')
def cart_quantity(product, cart):
    keys = cart.keys()
    for id in keys:
        if int(id) == product.id:
            return cart.get(id)
    return 0;


@register.filter(name='quantity_price')
def quantity_price(product, cart):
    return product.price * cart_quantity(product, cart)


@register.filter(name="totall_cart_price")
def totall_cart_price(product, cart):
    sum = 0
    for p in product:
        sum += quantity_price(p, cart)
    return sum


@register.filter(name='english_convert')
def english_convert(n):
    number = ["", "one", "two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"]
    nty = ["", "", "Twenty", "Thirty", "Fourty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninty"]
    tens = ["Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Ninteen"]

    if n > 99999:
        print("Can't Solve This!!")

    else:
        d = [0, 0, 0, 0, 0]
        i = 0
        num = ""
        while n > 0:
            d[i] = n % 10
            i += 1
            n = n // 10

        if d[4] != 0:
            if d[4] == 1:
                num += tens[d[3]] + " Thousand "
            else:
                num += nty[d[4]] + " " + number[d[3]] + " Thousand "

        else:
            if d[3] != 0:
                num += number[d[3]] + " Thousand "

        if d[2] != 0:
            num += number[d[2]] + " Hundred "

        if d[1] != 0:
            if d[1] == 1:
                num += tens[d[0]]
            else:
                num += nty[d[1]] + " " + number[d[0]]
        else:
            num += number[d[0]]

        return num


@register.filter(name='hindi_convert')
def hindi_convert(n):
    number = ["", "एक", "दो", "तीन", "चार", "पांच", "छह", "सात", "आठ", "नौ", "दस", "ग्यारह", "बारह", "तेरह", "चौदह",
              "पंद्रह",
              "सोलह", "सत्रह", "अठारह", "उन्नीस", "बीस", "इकीस", "बाईस", "तेइस", "चौबीस", "पच्चीस", "छब्बीस", "सताइस",
              "अट्ठाइस", "उनतीस",
              "तीस", "इकतीस", "बतीस", "तैंतीस", "चौंतीस", "पैंतीस", "छतीस", "सैंतीस", "अड़तीस", "उनतालीस",
              "चालीस", "इकतालीस", "बयालीस", "तैतालीस", "चवालीस", "पैंतालीस", "छयालिस", "सैंतालीस", "अड़तालीस", "उनचास",
              "पचास", "इक्यावन",
              "बावन", "तिरपन", "चौवन", "पचपन", "छप्पन", "सतावन", "अठावन", "उनसठ", "साठ", "इकसठ", "बासठ", "तिरसठ",
              "चौंसठ",
              "पैंसठ", "छियासठ", "सड़सठ",
              "अड़सठ", "उनहत्तर", "सत्तर", "इकहत्तर", "बहत्तर", "तिहत्तर", "चौहत्तर", "पचहत्तर", "छिहत्तर", "सतत्तर",
              "अठहत्तर", "उन्नासी", "अस्सी",
              "इक्यासी", "बयासी", "तिरासी", "चौरासी", "पचासी", "छियासी", "सतासी", "अट्ठासी", "नवासी", "नब्बे",
              "इक्यानवे", 'बानवे',
              'तिरानवे', 'चौरानवे', 'पचानवे',
              'छियानवे', 'सतानवे', "अट्ठानवे", "निन्यानवे"]

    if n > 99999:
        print("Can't Solve This!")

    else:
        d = [0, 0, 0, 0, 0]
        i = 0
        num = ""

        while n > 0:
            d[i] = n % 10
            i += 1
            n = n // 10
        last_two_num = int(f'{d[1]}{d[0]}')
        first_two_num = int(f'{d[-1]}{d[-2]}')

        if d[4] != 0:

            num += number[first_two_num] + " हज़ार "
        else:
            if d[3] != 0:
                num += number[d[3]] + " हज़ार "

        if d[2] != 0:
            num += number[d[2]] + " सौ "

        if d[1] != 0:
            num += number[last_two_num]
        else:
            num += number[d[0]]

        return num


