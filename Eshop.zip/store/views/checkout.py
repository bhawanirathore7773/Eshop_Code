from django.shortcuts import redirect
from django.shortcuts import render
from django.views import View
from store.models.product import Product
from store.models.orders import Order
from store.models.customer import Customer


class CheckOut(View):

    def post(self, request):
        customer = request.session.get('customer')
        address = request.POST.get('Address')
        phone = request.POST.get('Phone')
        cart = request.session.get('cart')
        products = Product.get_product_by_id(list(cart.keys()))

        if  products:
            for product in products:
                print(product.id)
                print("hello world!")
                cart = request.session.get('cart')
                print(cart)
                quantity = cart[f"{str(product.id)} " ]


                orders = Order(
                    customer=Customer(id=customer),
                    address=address,
                    phone=phone,
                    product=product,
                    price=product.price,
                    quantity= cart.get(f"{str(product.id)} ")

                )
                orders.save()

            request.session['cart'] = {}



        return redirect('cart')

