
from django.shortcuts import render
from django.views import View
from store.models.product import Product


class Cart(View):

    def get(self, request):
        dict = request.session.get('cart').values()
        value = Product.cart_value_sum(dict)
        ids = list(request.session.get('cart').keys())
        product = Product.get_product_by_id(ids)
        doc = {'product':product,
               'value':value}

        return render(request, 'cart.html',doc)

